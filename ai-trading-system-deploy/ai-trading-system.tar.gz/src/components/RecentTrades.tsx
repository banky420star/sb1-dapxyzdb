import React from 'react'
import { TrendingUp, TrendingDown } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { useTradingContext } from '../contexts/TradingContext'

export default function RecentTrades() {
  const { state } = useTradingContext()
  const trades = state.positions // or state.trades if available

  if (!trades || trades.length === 0) {
    return (
      <div className="text-gray-500 text-sm text-center py-8">No recent trades.</div>
    )
  }

  return (
    <div className="space-y-3">
      {trades.map((trade) => (
        <div key={trade.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white dark:bg-gray-900 rounded-lg">
              {trade.pnl >= 0 ? (
                <TrendingUp className="h-5 w-5 text-success-500" />
              ) : (
                <TrendingDown className="h-5 w-5 text-danger-500" />
              )}
            </div>
            <div>
              <h4 className="font-medium text-gray-900 dark:text-gray-100">{trade.symbol}</h4>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                {trade.side} • Size: {trade.size} • Entry: {trade.entryPrice} • P&L: {trade.pnl}
              </p>
            </div>
          </div>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {formatDistanceToNow(new Date(trade.timestamp), { addSuffix: true })}
          </span>
        </div>
      ))}
    </div>
  )
}