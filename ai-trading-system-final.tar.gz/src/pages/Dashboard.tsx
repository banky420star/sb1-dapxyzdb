import React, { useState, useEffect } from 'react'
import { useTradingContext } from '../contexts/TradingContext'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Activity,
  Brain,
  Shield,
  Zap,
  Target,
  Clock,
  Users,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Wifi,
  WifiOff,
  Bot,
  AlertTriangle
} from 'lucide-react'
import MetricCard from '../components/MetricCard'
import EquityCurve from '../components/EquityCurve'

export default function Dashboard() {
  const { state, socket } = useTradingContext()
  const [trainingActive, setTrainingActive] = useState(false)

  // Add null checks and default values
  const trades = state.trades || []
  const models = state.models || []
  const positions = state.positions || []
  const systemStatus = state.systemStatus || 'offline'
  
  // Use real-time data from context
  const realTimeData = {
    prices: state.realTimePrices || {},
    signals: state.realTimeSignals || [],
    lastUpdate: new Date().toISOString()
  }
  
  const aiStatus = state.aiStatus || {
    dataFetcher: { connected: false, isRunning: false },
    notificationAgent: null,
    models: []
  }

  // Update AI status based on actual data availability
  const isDataConnected = Object.keys(realTimeData.prices).length > 0 && 
    Object.values(realTimeData.prices).some(price => price && price.timestamp)

  useEffect(() => {
    if (!socket) return
    socket.on('training_started', () => setTrainingActive(true))
    socket.on('training_completed', () => setTrainingActive(false))
    socket.on('training_failed', () => setTrainingActive(false))
    socket.on('models_update', (models) => {
      setTrainingActive(models.some(m => m.status === 'training'))
    })
    return () => {
      socket.off('training_started')
      socket.off('training_completed')
      socket.off('training_failed')
      socket.off('models_update')
    }
  }, [socket])

  const metrics = [
    {
      title: 'Total P&L',
      value: `$${(state.totalPnL || 0).toFixed(2)}`,
      change: state.pnlChange || 0,
      changeType: (state.pnlChange || 0) >= 0 ? 'positive' as const : 'negative' as const,
      icon: DollarSign,
      color: 'green' as const,
      trend: (state.pnlChange || 0) >= 0 ? 'up' as const : 'down' as const,
      description: 'Total profit and loss'
    },
    {
      title: 'Win Rate',
      value: `${((state.winRate || 0) * 100).toFixed(1)}%`,
      change: (state.winRate || 0) - 0.5,
      changeType: (state.winRate || 0) >= 0.5 ? 'positive' as const : 'negative' as const,
      icon: Target,
      color: 'blue' as const,
      trend: (state.winRate || 0) >= 0.5 ? 'up' as const : 'down' as const,
      description: 'Percentage of winning trades'
    },
    {
      title: 'Active Positions',
      value: positions.length.toString(),
      change: 0,
      changeType: 'neutral' as const,
      icon: TrendingUp,
      color: 'purple' as const,
      trend: 'neutral' as const,
      description: 'Currently open positions'
    },
    {
      title: 'System Load',
      value: `${((state.systemLoad || 0) * 100).toFixed(1)}%`,
      change: 0,
      changeType: (state.systemLoad || 0) < 0.8 ? 'positive' as const : 'negative' as const,
      icon: Activity,
      color: (state.systemLoad || 0) < 0.8 ? 'green' as const : 'red' as const,
      trend: (state.systemLoad || 0) < 0.8 ? 'neutral' as const : 'up' as const,
      description: 'Current system utilization'
    },
    {
      title: 'Model Accuracy',
      value: `${((state.modelAccuracy || 0) * 100).toFixed(1)}%`,
      change: (state.modelAccuracy || 0) - 0.6,
      changeType: (state.modelAccuracy || 0) >= 0.6 ? 'positive' as const : 'negative' as const,
      icon: Brain,
      color: 'indigo' as const,
      trend: (state.modelAccuracy || 0) >= 0.6 ? 'up' as const : 'down' as const,
      description: 'Average model prediction accuracy'
    },
    {
      title: 'Risk Level',
      value: state.riskLevel || 'Low',
      change: 0,
      changeType: 'neutral' as const,
      icon: Shield,
      color: 'yellow' as const,
      trend: 'neutral' as const,
      description: 'Current risk assessment'
    }
  ]

  const quickStats = [
    {
      label: 'Total Trades',
      value: trades.length.toString(),
      icon: Activity,
      color: 'blue' as const
    },
    {
      label: 'Avg Trade Time',
      value: '2.4h',
      icon: Clock,
      color: 'green' as const
    },
    {
      label: 'Max Drawdown',
      value: '12.3%',
      icon: TrendingDown,
      color: 'red' as const
    },
    {
      label: 'Risk Score',
      value: 'Low',
      icon: Shield,
      color: 'purple' as const
    }
  ]

  return (
    <div className="space-y-6 md:space-y-8">
      {trainingActive && (
        <div className="bg-yellow-50 border border-yellow-300 rounded-lg p-4 flex items-center space-x-3 mb-4">
          <Activity className="w-6 h-6 text-yellow-600 animate-spin" />
          <span className="text-yellow-800 font-semibold">Model training in progress.</span>
          <a href="/models" className="ml-auto px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">View Training Visualization</a>
        </div>
      )}
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <div className="space-y-2">
          <h1 className="mobile-heading font-bold text-gray-900 dark:text-white">Trading Dashboard</h1>
          <p className="mobile-text text-gray-600 dark:text-gray-400">
            System overview and performance metrics
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className={`px-4 md:px-6 py-2 md:py-3 rounded-xl md:rounded-2xl text-xs md:text-sm font-semibold shadow-lg ${
            systemStatus === 'online' 
              ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
              : systemStatus === 'offline'
              ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white'
              : 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white'
          }`}>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                systemStatus === 'online' ? 'bg-white' : 'bg-white/80'
              }`} />
              <span>{systemStatus.charAt(0).toUpperCase() + systemStatus.slice(1)}</span>
            </div>
          </div>
          
          {/* AI Status Indicator */}
          <div className={`px-4 md:px-6 py-2 md:py-3 rounded-xl md:rounded-2xl text-xs md:text-sm font-semibold shadow-lg ${
            isDataConnected
              ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
              : 'bg-gradient-to-r from-gray-500 to-gray-600 text-white'
          }`}>
            <div className="flex items-center space-x-2">
              <Bot className="w-4 h-4" />
              <span>AI {isDataConnected ? 'Active' : 'Offline'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Data Status */}
      <div className="mobile-card glass-card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="mobile-heading font-bold text-gray-900 dark:text-white">Real-time Data</h2>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full animate-pulse ${
              isDataConnected ? 'bg-green-500' : 'bg-red-500'
            }`} />
            <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">
              {isDataConnected ? 'Live' : 'Offline'}
            </span>
            {isDataConnected && (
              <span className="text-xs text-gray-500 dark:text-gray-400">
                Last: {new Date(realTimeData.lastUpdate).toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>
        
        <div className="mobile-grid md:tablet-grid lg:desktop-grid gap-4">
          {Object.entries(realTimeData.prices).map(([symbol, price]) => (
            <div key={symbol} className="bg-white/10 dark:bg-gray-800/10 rounded-xl p-3 border border-white/20 dark:border-gray-700/20 relative">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-gray-900 dark:text-white">{symbol}</span>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {price.bid?.toFixed(5) || 'N/A'}
                </span>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Spread: {price.spread?.toFixed(5) || 'N/A'}
              </div>
              {price.timestamp && (
                <div className="text-xs text-gray-400 mt-1">
                  {new Date(price.timestamp).toLocaleTimeString()}
                </div>
              )}
              {/* Real-time indicator */}
              <div className="absolute top-2 right-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Trading Signals */}
        {realTimeData.signals.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">Recent Signals</h3>
            <div className="space-y-2">
              {realTimeData.signals.slice(0, 3).map((signal, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-white/5 dark:bg-gray-800/5 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${
                      signal.signal === 'BUY' ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {signal.symbol} {signal.signal}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {(signal.confidence * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* No data message */}
        {Object.keys(realTimeData.prices).length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <Activity className="w-8 h-8 mx-auto mb-2 animate-spin" />
            <p>Waiting for real-time data...</p>
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="mobile-grid md:tablet-grid gap-4">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="status-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                  <p className="text-lg md:text-xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                </div>
                <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl bg-gradient-to-br from-${stat.color}-500 to-${stat.color}-600 flex items-center justify-center`}>
                  <Icon className="h-4 w-4 md:h-5 md:w-5 text-white" />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Metrics Grid */}
      <div className="mobile-grid md:tablet-grid lg:desktop-grid gap-4 md:gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      {/* Equity Curve */}
      <div className="trading-card">
        <div className="flex items-center justify-between mb-4 md:mb-6">
          <h2 className="mobile-heading font-bold text-gray-900 dark:text-white">Performance Overview</h2>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Live</span>
          </div>
        </div>
        <div className="mobile-chart">
          <EquityCurve />
        </div>
      </div>

      {/* System Status */}
      <div className="mobile-grid md:tablet-grid gap-4 md:gap-6">
        {/* Recent Activity */}
        <div className="trading-card">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {trades.slice(-5).reverse().map((trade, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    trade.pnl >= 0 ? 'bg-green-500' : 'bg-red-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white text-sm md:text-base">{trade.symbol}</p>
                    <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400">
                      {new Date(trade.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-semibold text-sm md:text-base ${
                    trade.pnl >= 0 ? 'profit' : 'loss'
                  }`}>
                    ${trade.pnl?.toFixed(2) || '0.00'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {trade.side}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Models Status */}
        <div className="trading-card">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-4">AI Models</h3>
          <div className="space-y-3">
            {aiStatus.models?.slice(0, 5).map((model, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    model.status === 'online' ? 'bg-green-500' : 'bg-red-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white text-sm md:text-base">{model.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Accuracy: {(model.accuracy * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs md:text-sm font-semibold text-gray-900 dark:text-white">
                    {model.status}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    v{model.version}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}