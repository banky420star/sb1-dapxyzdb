# AI Trading System - Operations Runbook

## 🚨 Emergency Contacts & Escalation

| Role | Contact | Escalation Time |
|------|---------|----------------|
| Primary On-Call | Trading Ops Team | Immediate |
| Secondary | DevOps Lead | 15 minutes |
| Management | CTO | 1 hour |

**Emergency Slack Channel:** `#trading-ops-alerts`  
**PagerDuty Integration:** Enabled for P0/P1 alerts

---

## 🎯 Alert Glossary & Response

### P0 - Critical System Failure

#### **🔴 PM2 High Restart Rate**
- **Trigger:** `pm2_process_restarts > 3 in 5 minutes`
- **Impact:** Service instability, potential data loss
- **Response:**
  ```bash
  # Check PM2 status
  pm2 status
  pm2 logs --lines 50
  
  # Identify failing process
  pm2 describe [process_name]
  
  # Manual restart if needed
  pm2 restart ecosystem.config.cjs --update-env
  ```
- **Escalation:** If restarts persist after manual intervention

#### **🔴 Database Connection Pool Exhausted**
- **Trigger:** `database_connections_active >= database_connections_max`
- **Impact:** Application cannot process new requests
- **Response:**
  ```bash
  # Check PostgreSQL connections
  psql $DATABASE_URL -c "SELECT count(*) FROM pg_stat_activity;"
  
  # Kill long-running queries
  psql $DATABASE_URL -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle in transaction' AND state_change < now() - interval '5 minutes';"
  
  # Restart application if needed
  pm2 restart all
  ```

#### **🔴 Rate Gate API Exhaustion**
- **Trigger:** `rate_gate_backoff_count > 10 per minute`
- **Impact:** External API calls blocked, trading halted
- **Response:**
  ```bash
  # Check rate gate status
  curl http://localhost:3001/status
  
  # Reset quotas (emergency only)
  curl -X POST http://localhost:3001/reset
  
  # Monitor quota usage
  curl http://localhost:3001/metrics
  ```

### P1 - Service Degradation

#### **🟡 Negative Sharpe Ratio**
- **Trigger:** `trading_sharpe_ratio < 0 for 15 minutes`
- **Impact:** Trading strategy underperforming
- **Response:**
  ```bash
  # Check trading performance
  curl http://localhost:8000/api/metrics/performance
  
  # Review recent trades
  curl http://localhost:8000/api/trades?limit=20
  
  # Check model accuracy
  curl http://localhost:8000/api/models/status
  
  # Consider disabling auto-trading
  curl -X POST http://localhost:8000/api/trading/disable
  ```

#### **🟡 High API Latency**
- **Trigger:** `http_request_duration_p95 > 2s`
- **Impact:** Slow response times, poor user experience
- **Response:**
  ```bash
  # Check system resources
  top
  df -h
  free -m
  
  # Review application logs
  pm2 logs --lines 100
  
  # Check database performance
  psql $DATABASE_URL -c "SELECT query, mean_exec_time FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;"
  ```

### P2 - Minor Issues

#### **🟢 Backup Failure**
- **Trigger:** Backup script exit code != 0
- **Impact:** DR capability reduced
- **Response:**
  ```bash
  # Check backup logs
  tail -50 /var/log/postgres-backup.log
  tail -50 /var/log/redis-backup.log
  
  # Manual backup execution
  ./scripts/backup-postgres.sh
  ./scripts/backup-redis.sh
  
  # Verify S3 uploads
  aws s3 ls s3://ai-trading-backups/postgres/
  ```

---

## 🔄 Rollback Procedures

### Application Rollback (Helm)
```bash
# List recent deployments
helm history ats -n trading

# Rollback to previous version
helm rollback ats [REVISION] -n trading

# Verify rollback
kubectl get pods -n trading
curl http://localhost:8000/api/health
```

### Database Migration Rollback
```bash
# Connect to database
psql $DATABASE_URL

-- Check migration status
SELECT * FROM schema_migrations ORDER BY version DESC LIMIT 5;

-- Rollback migration (if supported)
-- NOTE: Many migrations are irreversible - coordinate with dev team
```

### PM2 Configuration Rollback
```bash
# Backup current config
cp ecosystem.config.cjs ecosystem.config.backup.cjs

# Restore from backup
git checkout HEAD~1 -- ecosystem.config.cjs
pm2 reload ecosystem.config.cjs
```

---

## 📊 Service Health Checks

### Quick Health Verification
```bash
#!/bin/bash
# health-check.sh

echo "=== System Health Check ==="

# API Health
echo "API Health:"
curl -s http://localhost:8000/api/health | jq .

# Database
echo "Database:"
psql $DATABASE_URL -c "SELECT 1;" > /dev/null && echo "✅ Connected" || echo "❌ Failed"

# Redis
echo "Redis:"
redis-cli ping > /dev/null && echo "✅ Connected" || echo "❌ Failed"

# PM2 Status
echo "PM2 Processes:"
pm2 status --no-color

# Docker Services
echo "Docker Services:"
docker compose ps

# Disk Space
echo "Disk Usage:"
df -h | grep -E "(/$|/var|/tmp)"

# Memory
echo "Memory Usage:"
free -m

echo "=== Health Check Complete ==="
```

### Performance Baseline
| Metric | Normal Range | Alert Threshold |
|--------|--------------|----------------|
| CPU Usage | < 70% | > 85% |
| Memory Usage | < 80% | > 90% |
| API Response Time (p95) | < 500ms | > 2s |
| Database Connections | < 80% of max | > 90% of max |
| Disk Usage | < 80% | > 90% |

---

## 🔧 Common Troubleshooting

### High Memory Usage
```bash
# Find memory-heavy processes
ps aux --sort=-%mem | head -10

# Check Node.js heap usage
curl http://localhost:8000/api/metrics/memory

# Restart PM2 processes
pm2 restart all
```

### Slow Database Queries
```bash
# Enable query logging (temporarily)
psql $DATABASE_URL -c "ALTER SYSTEM SET log_min_duration_statement = 1000;"
psql $DATABASE_URL -c "SELECT pg_reload_conf();"

# Check slow queries
psql $DATABASE_URL -c "SELECT query, mean_exec_time, calls FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;"

# Reset statistics
psql $DATABASE_URL -c "SELECT pg_stat_statements_reset();"
```

### WebSocket Connection Issues
```bash
# Check active WebSocket connections
curl http://localhost:8000/api/metrics/websockets

# Test WebSocket connectivity
wscat -c ws://localhost:8000/ws/market

# Check nginx proxy (if used)
nginx -t
systemctl status nginx
```

### Rate Limiting Issues
```bash
# Check current quotas
curl http://localhost:3001/status

# View rate limiting metrics
curl http://localhost:3001/metrics

# Reset specific provider quota (emergency)
curl -X POST http://localhost:3001/reset/alphavantage
```

---

## 📈 Monitoring & Observability

### Key Dashboards
1. **System Performance:** http://localhost:3000/d/system-perf
2. **API Latency:** http://localhost:3000/d/api-latency  
3. **Trading P&L:** http://localhost:3000/d/trading-pnl

### Log Locations
```bash
# Application logs
pm2 logs
tail -f logs/combined.log

# System logs
journalctl -u docker
journalctl -f

# Backup logs
tail -f /var/log/postgres-backup.log
tail -f /var/log/redis-backup.log

# Grafana logs (in container)
docker logs grafana
```

### Key Metrics to Monitor
- **Trading Performance:** Sharpe ratio, max drawdown, win rate
- **System Health:** CPU, memory, disk usage
- **API Performance:** Response times, error rates
- **Data Pipeline:** ML model accuracy, feature freshness

---

## 🛡️ Security Incident Response

### Suspected Breach
1. **Immediate:** Disable external API access
   ```bash
   # Block external traffic
   sudo iptables -A OUTPUT -p tcp --dport 443 -j DROP
   ```

2. **Isolate:** Stop trading activities
   ```bash
   curl -X POST http://localhost:8000/api/trading/emergency-stop
   ```

3. **Investigate:** Check logs for anomalies
   ```bash
   grep -E "(error|unauthorized|failed)" logs/combined.log | tail -100
   ```

4. **Escalate:** Contact security team immediately

### API Key Compromise
```bash
# Rotate API keys immediately
# 1. Update environment variables
# 2. Restart services
pm2 restart all --update-env

# 3. Verify new keys working
curl http://localhost:8000/api/health
```

---

## 💾 Backup & Recovery

### Database Recovery
```bash
# List available backups
aws s3 ls s3://ai-trading-backups/postgres/

# Download backup
aws s3 cp s3://ai-trading-backups/postgres/trading_db_2025-01-20.dump /tmp/

# Restore database
dropdb trading_db_recovery
createdb trading_db_recovery
pg_restore --verbose --clean --no-acl --no-owner -d trading_db_recovery /tmp/trading_db_2025-01-20.dump
```

### Redis Recovery
```bash
# Stop Redis
systemctl stop redis

# Restore RDB file
cp /var/backups/redis/redis_latest.rdb.gz /var/lib/redis/
gunzip /var/lib/redis/redis_latest.rdb.gz
mv /var/lib/redis/redis_latest.rdb /var/lib/redis/dump.rdb

# Start Redis
systemctl start redis
```

### Application Recovery (Clean Deployment)
```bash
# Clone fresh repository
git clone https://github.com/banky420star/sb1-dapxyzdb.git recovery
cd recovery

# Deploy clean stack
docker compose down -v
docker compose up --build -d

# Verify services
./scripts/deployment-verification.sh
```

---

## 📞 Contact Information

| Service | URL | Credentials |
|---------|-----|-------------|
| Grafana | http://localhost:3000 | admin/admin123 |
| MLflow | http://localhost:5000 | None |
| Prometheus | http://localhost:9090 | None |
| Trading API | http://localhost:8000 | Bearer token |

**Emergency Procedures:**
- For P0 alerts: Page on-call engineer immediately
- For data corruption: Stop all trading, contact dev team
- For security incidents: Follow incident response protocol

**Documentation Updates:**
This runbook should be updated after each deployment and reviewed monthly.

---

*Last Updated: January 2025*  
*Version: 1.0*  
*Owner: Trading Operations Team* 