#!/bin/bash

# PostgreSQL Backup Script for AI Trading System
# Performs logical backup and uploads to S3 Glacier for DR

set -e

# Configuration
BACKUP_DIR="/tmp/backups"
DATE=$(date +%F_%H-%M-%S)
BACKUP_FILE="trading_db_${DATE}.dump"
S3_BUCKET="${AWS_S3_BACKUP_BUCKET:-ai-trading-backups}"
RETENTION_DAYS=30

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check prerequisites
command -v pg_dump >/dev/null 2>&1 || error "pg_dump not found. Install PostgreSQL client tools."
command -v aws >/dev/null 2>&1 || error "AWS CLI not found. Install AWS CLI."

# Check environment variables
[ -z "$DATABASE_URL" ] && error "DATABASE_URL environment variable not set"
[ -z "$AWS_ACCESS_KEY_ID" ] && warn "AWS_ACCESS_KEY_ID not set, using IAM role or default profile"

# Create backup directory
mkdir -p "$BACKUP_DIR"

log "Starting PostgreSQL backup..."

# Perform logical backup with custom format (compressed)
pg_dump -Fc \
    --verbose \
    --no-acl \
    --no-owner \
    --dbname="$DATABASE_URL" \
    --file="$BACKUP_DIR/$BACKUP_FILE" || error "pg_dump failed"

# Get backup file size
BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
log "Backup completed: $BACKUP_FILE ($BACKUP_SIZE)"

# Upload to S3 with Glacier storage class
log "Uploading backup to S3..."
aws s3 cp "$BACKUP_DIR/$BACKUP_FILE" \
    "s3://$S3_BUCKET/postgres/" \
    --storage-class GLACIER \
    --metadata "source=trading-system,date=$DATE,size=$BACKUP_SIZE" || error "S3 upload failed"

log "Backup uploaded to s3://$S3_BUCKET/postgres/$BACKUP_FILE"

# Clean up local backup file
rm -f "$BACKUP_DIR/$BACKUP_FILE"
log "Local backup file cleaned up"

# Clean up old S3 backups (older than retention period)
log "Cleaning up old backups (older than $RETENTION_DAYS days)..."
CUTOFF_DATE=$(date -d "$RETENTION_DAYS days ago" +%Y-%m-%d)

# List and delete old backups
aws s3 ls "s3://$S3_BUCKET/postgres/" | while read -r line; do
    BACKUP_DATE=$(echo "$line" | awk '{print $1}')
    BACKUP_NAME=$(echo "$line" | awk '{print $4}')
    
    if [[ "$BACKUP_DATE" < "$CUTOFF_DATE" ]]; then
        log "Deleting old backup: $BACKUP_NAME (date: $BACKUP_DATE)"
        aws s3 rm "s3://$S3_BUCKET/postgres/$BACKUP_NAME" || warn "Failed to delete $BACKUP_NAME"
    fi
done

# Verify backup integrity (optional restore test)
if [ "${VERIFY_BACKUP:-false}" = "true" ]; then
    log "Verifying backup integrity..."
    
    # Create temporary test database
    TEST_DB="trading_test_$(date +%s)"
    createdb "$TEST_DB" || warn "Failed to create test database"
    
    # Restore backup to test database
    pg_restore \
        --verbose \
        --clean \
        --no-acl \
        --no-owner \
        --dbname="$TEST_DB" \
        "$BACKUP_DIR/$BACKUP_FILE" || warn "Backup verification failed"
    
    # Clean up test database
    dropdb "$TEST_DB" || warn "Failed to drop test database"
    
    log "Backup verification completed successfully"
fi

# Send notification (if Slack webhook is configured)
if [ -n "$SLACK_WEBHOOK" ]; then
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"✅ Trading System DB Backup completed: $BACKUP_FILE ($BACKUP_SIZE)\"}" \
        "$SLACK_WEBHOOK" || warn "Failed to send Slack notification"
fi

log "PostgreSQL backup process completed successfully" 