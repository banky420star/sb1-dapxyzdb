#!/bin/bash

# Redis Backup Script for AI Trading System
# Performs RDB snapshot every 5 minutes for rate limiting data

set -e

# Configuration
REDIS_HOST="${REDIS_HOST:-localhost}"
REDIS_PORT="${REDIS_PORT:-6379}"
REDIS_PASSWORD="${REDIS_PASSWORD:-}"
BACKUP_DIR="/var/backups/redis"
DATE=$(date +%F_%H-%M-%S)
BACKUP_FILE="redis_${DATE}.rdb"
MAX_BACKUPS=288  # Keep 24 hours of 5-minute backups

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check prerequisites
command -v redis-cli >/dev/null 2>&1 || error "redis-cli not found. Install Redis client tools."

# Create backup directory
mkdir -p "$BACKUP_DIR"

log "Starting Redis RDB backup..."

# Construct redis-cli command
REDIS_CMD="redis-cli -h $REDIS_HOST -p $REDIS_PORT"
if [ -n "$REDIS_PASSWORD" ]; then
    REDIS_CMD="$REDIS_CMD -a $REDIS_PASSWORD"
fi

# Test Redis connection
$REDIS_CMD ping >/dev/null 2>&1 || error "Cannot connect to Redis at $REDIS_HOST:$REDIS_PORT"

# Trigger background save
log "Triggering BGSAVE..."
$REDIS_CMD BGSAVE || error "BGSAVE command failed"

# Wait for background save to complete
log "Waiting for background save to complete..."
while [ "$($REDIS_CMD LASTSAVE)" = "$($REDIS_CMD LASTSAVE)" ]; do
    sleep 1
done

# Get Redis data directory
REDIS_DIR=$($REDIS_CMD CONFIG GET dir | tail -1)
REDIS_DBFILE=$($REDIS_CMD CONFIG GET dbfilename | tail -1)
SOURCE_RDB="$REDIS_DIR/$REDIS_DBFILE"

# Copy RDB file to backup location
if [ -f "$SOURCE_RDB" ]; then
    cp "$SOURCE_RDB" "$BACKUP_DIR/$BACKUP_FILE" || error "Failed to copy RDB file"
    BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
    log "Redis backup completed: $BACKUP_FILE ($BACKUP_SIZE)"
else
    error "Redis RDB file not found at $SOURCE_RDB"
fi

# Compress backup to save space
gzip "$BACKUP_DIR/$BACKUP_FILE" || warn "Failed to compress backup"
BACKUP_FILE="$BACKUP_FILE.gz"

# Clean up old backups (keep only last N backups)
log "Cleaning up old backups (keeping last $MAX_BACKUPS)..."
cd "$BACKUP_DIR" || error "Cannot access backup directory"
ls -t redis_*.rdb.gz 2>/dev/null | tail -n +$((MAX_BACKUPS + 1)) | xargs rm -f || true

# Get backup statistics
TOTAL_BACKUPS=$(ls redis_*.rdb.gz 2>/dev/null | wc -l)
TOTAL_SIZE=$(du -sh . | cut -f1)

log "Backup cleanup completed. Total backups: $TOTAL_BACKUPS, Total size: $TOTAL_SIZE"

# Verify backup integrity (quick check)
log "Verifying backup integrity..."
if gunzip -t "$BACKUP_DIR/$BACKUP_FILE" 2>/dev/null; then
    log "Backup integrity check passed"
else
    error "Backup integrity check failed - file may be corrupted"
fi

# Optional: Upload to S3 for additional redundancy
if [ "${ENABLE_S3_BACKUP:-false}" = "true" ] && command -v aws >/dev/null 2>&1; then
    S3_BUCKET="${AWS_S3_BACKUP_BUCKET:-ai-trading-backups}"
    log "Uploading Redis backup to S3..."
    aws s3 cp "$BACKUP_DIR/$BACKUP_FILE" \
        "s3://$S3_BUCKET/redis/" \
        --metadata "source=trading-system,date=$DATE" || warn "S3 upload failed"
fi

log "Redis backup process completed successfully" 